import 'dotenv/config';
import express from 'express';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const E = process.env;
if (!E.JWT_SECRET) { console.error('Set JWT_SECRET in .env'); process.exit(1); }
const db = new Database(E.DB_PATH || 'neural.db');
db.exec(`
create table if not exists users(id integer primary key, email text unique, hash text);
create table if not exists chats(id integer primary key, user_id integer, title text, provider text, fav integer default 0, created integer default (strftime('%s','now')));
create table if not exists messages(id integer primary key, chat_id integer, role text, provider text, content text, att text default '[]');
create index if not exists m_chat on messages(chat_id);`);

// ---------- AI providers (real API calls, keys only from env) ----------
const txt = m => m.content + m.att.filter(a => a.kind === 'text').map(a => `\n\n[File: ${a.name}]\n${a.data}`).join('');
const imgs = m => m.att.filter(a => a.kind === 'image');
async function post(url, headers, body, pick) {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(120000) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error?.message || `HTTP ${r.status}${r.status === 429 ? ' (rate limit)' : ''}`);
  return pick(j);
}
const openaiLike = (url, key, model, vision) => h => {
  if (!key) throw new Error('API key is not configured on the server');
  const msg = m => ({ role: m.role, content: vision && imgs(m).length
    ? [{ type: 'text', text: txt(m) }, ...imgs(m).map(i => ({ type: 'image_url', image_url: { url: `data:${i.mime};base64,${i.data}` } }))] : txt(m) });
  return post(url, { authorization: 'Bearer ' + key }, { model, messages: h.map(msg) }, j => j.choices[0].message.content);
};
const PROV = {
  openai: openaiLike('https://api.openai.com/v1/chat/completions', E.OPENAI_API_KEY, E.OPENAI_MODEL || 'gpt-4o', true),
  deepseek: openaiLike('https://api.deepseek.com/chat/completions', E.DEEPSEEK_API_KEY, E.DEEPSEEK_MODEL || 'deepseek-chat', false),
  anthropic: h => {
    if (!E.ANTHROPIC_API_KEY) throw new Error('API key is not configured on the server');
    const msg = m => ({ role: m.role, content: [...imgs(m).map(i => ({ type: 'image', source: { type: 'base64', media_type: i.mime, data: i.data } })), { type: 'text', text: txt(m) }] });
    return post('https://api.anthropic.com/v1/messages', { 'x-api-key': E.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      { model: E.ANTHROPIC_MODEL || 'claude-sonnet-4-5', max_tokens: 4096, messages: h.map(msg) }, j => j.content.map(c => c.text || '').join(''));
  },
};

// ---------- app ----------
const app = express();
app.use((req, res, next) => { // CORS for the Android (Capacitor) client; auth is a Bearer token, no cookies
  res.set({ 'Access-Control-Allow-Origin': E.CORS_ORIGIN || '*', 'Access-Control-Allow-Headers': 'content-type,authorization', 'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS' });
  req.method === 'OPTIONS' ? res.sendStatus(204) : next();
});
app.use(express.json({ limit: '30mb' }));
app.use(express.static('public'));
const sign = u => jwt.sign({ uid: u.id }, E.JWT_SECRET, { expiresIn: '30d' });
const auth = (req, res, next) => {
  try { req.uid = jwt.verify((req.headers.authorization || '').slice(7), E.JWT_SECRET).uid; next(); } catch { res.status(401).json({ error: 'auth' }); }
};
const own = req => db.prepare('select * from chats where id=? and user_id=?').get(req.params.id, req.uid);
const msgs = id => db.prepare('select * from messages where chat_id=? order by id').all(id).map(m => ({ ...m, att: JSON.parse(m.att || '[]') }));

app.post('/api/register', (req, res) => {
  const { email = '', password = '' } = req.body;
  if (!/^\S+@\S+$/.test(email) || password.length < 6) return res.status(400).json({ error: 'Valid email and password (6+ chars) required' });
  try { const r = db.prepare('insert into users(email,hash) values(?,?)').run(email.toLowerCase(), bcrypt.hashSync(password, 10)); res.json({ token: sign({ id: r.lastInsertRowid }) }); }
  catch { res.status(409).json({ error: 'Email already registered' }); }
});
app.post('/api/login', (req, res) => {
  const u = db.prepare('select * from users where email=?').get((req.body.email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(req.body.password || '', u.hash)) return res.status(401).json({ error: 'Wrong email or password' });
  res.json({ token: sign(u) });
});
app.get('/api/chats', auth, (req, res) => {
  const q = `%${req.query.q || ''}%`;
  res.json(db.prepare(`select * from chats c where user_id=? and (title like ? or exists(select 1 from messages m where m.chat_id=c.id and m.content like ?)) order by fav desc, id desc`).all(req.uid, q, q));
});
app.post('/api/chats', auth, (req, res) => {
  const { provider, title = 'New chat', seed = [] } = req.body;
  if (!['openai', 'anthropic', 'deepseek', 'all'].includes(provider)) return res.status(400).json({ error: 'bad provider' });
  const id = db.prepare('insert into chats(user_id,title,provider) values(?,?,?)').run(req.uid, title, provider).lastInsertRowid;
  for (const m of seed) db.prepare('insert into messages(chat_id,role,provider,content) values(?,?,?,?)').run(id, m.role, m.role === 'assistant' ? provider : null, m.content);
  res.json(db.prepare('select * from chats where id=?').get(id));
});
app.get('/api/chats/:id', auth, (req, res) => { const c = own(req); c ? res.json({ ...c, messages: msgs(c.id) }) : res.sendStatus(404); });
app.patch('/api/chats/:id', auth, (req, res) => {
  const c = own(req); if (!c) return res.sendStatus(404);
  db.prepare('update chats set fav=?, title=? where id=?').run(req.body.fav ?? c.fav, req.body.title ?? c.title, c.id); res.json({ ok: 1 });
});
app.delete('/api/chats/:id', auth, (req, res) => {
  const c = own(req); if (!c) return res.sendStatus(404);
  db.prepare('delete from messages where chat_id=?').run(c.id); db.prepare('delete from chats where id=?').run(c.id); res.json({ ok: 1 });
});

app.post('/api/chats/:id/send', auth, async (req, res) => {
  const c = own(req); if (!c) return res.sendStatus(404);
  const { content = '', att = [], truncateFrom, regen } = req.body;
  if (truncateFrom) db.prepare('delete from messages where chat_id=? and id>=?').run(c.id, truncateFrom);
  if (!regen) {
    db.prepare('insert into messages(chat_id,role,content,att) values(?,?,?,?)').run(c.id, 'user', content, JSON.stringify(att));
    if (c.title === 'New chat') db.prepare('update chats set title=? where id=?').run(content.slice(0, 40) || 'Chat', c.id);
  }
  const all = msgs(c.id);
  await Promise.all((c.provider === 'all' ? Object.keys(PROV) : [c.provider]).map(async p => {
    const h = [];
    for (const m of all.filter(m => m.role === 'user' || (m.role === 'assistant' && m.provider === p))) {
      const last = h[h.length - 1];
      if (last && last.role === m.role) { last.content += '\n\n' + m.content; last.att = [...last.att, ...m.att]; } else h.push({ role: m.role, content: m.content, att: [...m.att] });
    }
    let role = 'assistant', out;
    try { out = await PROV[p](h); } catch (e) { role = 'error'; out = e.message; }
    db.prepare('insert into messages(chat_id,role,provider,content) values(?,?,?,?)').run(c.id, role, p, out || '');
  }));
  res.json({ ...db.prepare('select * from chats where id=?').get(c.id), messages: msgs(c.id) });
});

try { db.exec('alter table users add column settings text'); } catch {}
app.get('/api/settings', auth, (req, res) => res.json(JSON.parse(db.prepare('select settings s from users where id=?').get(req.uid)?.s || '{}')));
app.put('/api/settings', auth, (req, res) => { db.prepare('update users set settings=? where id=?').run(JSON.stringify(req.body).slice(0, 2000), req.uid); res.json({ ok: 1 }); });

app.listen(E.PORT || 3000, () => console.log(`NEURAL AI → http://localhost:${E.PORT || 3000}`));
