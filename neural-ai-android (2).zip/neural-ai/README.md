# NEURAL AI
ChatGPT + Claude + DeepSeek в одном приложении, режим **ALL AI**, настройки и кастомизация (Material 3 / Liquid Glass).

## Как это устроено
- `server.js` + `public/` — backend (Node.js, Express, SQLite) и веб-интерфейс. Ключи API лежат только на сервере (`.env`).
- `android/` + `capacitor.config.json` — Android-оболочка (Capacitor 6). **APK — это клиент**: он содержит интерфейс и ходит к вашему серверу. Поэтому backend должен быть развёрнут там, где его видит телефон (Render, Railway, Fly.io, VPS), **по HTTPS**.
- `.github/workflows/android.yml` — облачная сборка APK.

## 1. Запуск backend
```
npm install
cp .env.example .env     # JWT_SECRET и ключи OPENAI_API_KEY / ANTHROPIC_API_KEY / DEEPSEEK_API_KEY
npm start                # http://localhost:3000
```
Для продакшена задайте переменные окружения на хостинге (команда запуска `npm start`, нужен Node 18+, база `neural.db` должна лежать на постоянном диске). Необязательно: `CORS_ORIGIN` — ограничить домены.

## 2. Сборка APK в облаке (GitHub Actions)
1. Создайте репозиторий на GitHub и загрузите все файлы проекта (папку `.github` тоже).
2. Откройте **Actions → Build Android APK → Run workflow** (запускается и при каждом push в `main`).
3. Через 5–10 минут скачайте артефакт **neural-ai-debug-apk** со страницы запуска, распакуйте и установите `app-debug.apk` на телефон (разрешите установку из неизвестных источников).
4. При первом входе в приложение введите адрес вашего сервера (`https://ваш-сервер`) и зарегистрируйтесь.

## 3. Локальная сборка (необязательно)
Нужны Node 18+, JDK 17, Android SDK 34 и Gradle 8.2.1.
```
npm install --ignore-scripts
npx cap sync android
cd android && gradle assembleDebug      # APK: android/app/build/outputs/apk/debug/
```
Либо откройте папку `android/` в Android Studio (она сама создаст Gradle wrapper). После правок в `public/` выполняйте `npx cap sync android`.

## Примечания
- Это **debug**-APK (подписан отладочным ключом) — для установки и тестов. Для Google Play нужна release-сборка с вашим keystore (`gradle bundleRelease` + подпись).
- Сервер на `http://` Android блокирует (смешанное содержимое), используйте HTTPS.
- `gradle-wrapper.jar` не включён (бинарный файл): workflow ставит Gradle сам.
- Настройки внешнего вида сохраняются в браузере/приложении и в вашем аккаунте на сервере.
